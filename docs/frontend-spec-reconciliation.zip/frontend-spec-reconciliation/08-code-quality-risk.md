# 08 - Code Quality Risk

| Issue | Severity | File(s) | Explanation | Suggested Fix |
|---|---|---|---|---|
| Missing route guard/RBAC | CRITICAL | `src/app/(protected)/layout.tsx` | Protected routes render without auth or role checks. | Add auth bootstrap and central role guard. |
| Sidebar defaults to SYSTEM_ADMIN when user is null | HIGH | `src/components/layout/sidebar.tsx` | `MOCKED_SYSTEM_ADMIN_ROLES` makes unauthenticated/unknown state show admin nav. | Remove fallback; show loading/login state. |
| Build/lint cannot run in current environment | HIGH | `package.json` | `bun run lint` fails `eslint: command not found`; `bun run build` fails `Script not found "next"`. | Install/materialize dependencies and rerun verification. |
| Missing auth bootstrap after reload | HIGH | `src/app/providers.tsx`, `src/stores/use-auth-store.ts` | Store is memory-only; refresh interceptor only helps after an API 401, not initial route load. | Add bootstrap that calls refresh then `/auth/me`. |
| Unknown-device UX missing | HIGH | `src/lib/api/axios-config.ts`, `src/app/auth/login/page.tsx` | Login sends fingerprint but 403/device trust only becomes generic error. | Add contract-specific handling and request approval screen. |
| Broken sidebar route | HIGH | `src/config/navigation.ts` | Nav includes `/staff/devices`, but no page exists. | Remove until implemented or create later in device task. |
| Broken public links | MEDIUM | `src/app/auth/login/page.tsx` | Links to `/forgot-password`, `/terms`, `/privacy` with no route files. | Add routes later or remove/disable links. |
| Login field email-oriented | MEDIUM | `src/app/auth/login/page.tsx` | Spec says staff should use internal username; input type is `email`, label is Email. | Change after owner confirms username format. |
| No logout UI | MEDIUM | `src/service/user/api.ts`, `src/components/layout/sidebar.tsx` | Logout APIs exist but are unused. | Add user menu/logout in protected shell. |
| No centralized role navigation contract beyond simple groups | MEDIUM | `src/config/navigation.ts` | Current nav is shallow and misses many required modules. | Expand role navigation after phase decisions. |
| API client contract typing/docs mismatch | MEDIUM | `src/lib/api/axios-config.ts`, `docs/04-api-and-react-query.md` | Docs say interceptor returns data; current code returns Axios response on success. | Align docs/code in a dedicated API client task. |
| Hardcoded demo fingerprints | MEDIUM | `src/lib/auth/device-fingerprint.ts`, `src/app/auth/login/page.tsx` | Demo mappings are useful but can mask device trust behavior. | Keep clearly documented and isolate demo seed map. |
| Hardcoded role labels in sidebar footer | MEDIUM | `src/components/layout/sidebar.tsx` | Footer always displays `SYSTEM_ADMIN` text. | Render current user roles. |
| Missing staff/device/pricing/incident/PWA services | MEDIUM | `src/service/**` | Large spec areas have no contracts or UI. | Do not code until backend contracts are written. |
| No reusable data table abstraction | LOW | `src/features/admin/**`, `src/features/manager/**` | Tables repeat patterns but still manageable. | Extract only after repeated pagination/sort needs. |
| No confirmation for destructive delete | LOW | `src/features/admin/master-data-config.tsx` | Vehicle type delete is immediate button action. | Add confirmation dialog in CRUD hardening. |
| No error boundary/custom 404 | LOW | `src/app/**` | Missing shared error/not-found routes. | Add later as foundation polish. |
| No optimistic updates | LOW | Feature components | Mutations invalidate after success; acceptable for CRUD MVP. | Keep simple unless UX requires instant feedback. |
| Frontend sends tenantId manually | LOW | `src/service/manager/facility-api.ts` | No tenantId sent; this is correct per manager API doc. | Keep tenant JWT/session-owned. |
| Mixed server/client misuse | LOW | `src/app/**`, `src/features/**` | No obvious misuse found; client components correctly marked. | Continue App Router conventions. |
