# 04 - Spec vs UI Gap

Status values: DONE, PARTIAL, MOCK_ONLY, STATIC_ONLY, DOC_ONLY, MISSING, UNCLEAR.

| Spec Area | Required UI/UX | Current Frontend Status | Existing Routes/Files | Missing Components | Missing API Contract | Risk | Recommended Phase |
|---|---|---|---|---|---|---|---|
| Login/auth | Operational login, role redirect, no social login | PARTIAL | `src/app/auth/login/page.tsx` | Auth bootstrap, route guard, logout UI | Staff username format | Direct route access, reload loses session | PHASE_0_FOUNDATION |
| Device unknown screen | Blocking "Thiết bị lạ", request button | MISSING | `src/lib/api/axios-config.ts` | Unknown device route/screen | Device error code, request endpoint | Staff blocked with only toast | PHASE_1_CRUD_BASIC |
| System Admin dashboard | Active tenants, running parkings, health chart | PARTIAL | `/admin`, `src/features/admin/admin-dashboard.tsx` | Better health semantics | Confirm stats fields | Works only if backend ready | PHASE_1_CRUD_BASIC |
| Tenant management | Table, create, active/suspended | PARTIAL | `/admin/tenants`, `src/features/admin/tenant-management.tsx` | Edit/detail, username option | Manager username vs email | Tenant provisioning may not match staff/manager identity policy | PHASE_1_CRUD_BASIC |
| Master data vehicle types | CRUD/list/edit | DONE | `/admin/master-data`, `src/features/admin/master-data-config.tsx` | Confirm delete UX | Existing doc has contract | Low | PHASE_1_CRUD_BASIC |
| Role/permission UI | Roles/permissions list/edit if needed | PARTIAL | `src/features/admin/master-data-config.tsx` | Permissions matrix/edit | Permissions contract | Cannot manage RBAC | PHASE_1_CRUD_BASIC |
| Manager dashboard shell | Tenant operations dashboard | MOCK_ONLY | `/manager`, `src/components/role-welcome-card.tsx` | Real widgets/layout | Manager dashboard API | No manager overview | PHASE_1_CRUD_BASIC |
| Facility parking/floor/zone/slot | Parking, floor, zone, slot CRUD | PARTIAL | `/manager/parkings`, `/manager/parkings/[id]/topology`, `/manager/slots` | Parking create/edit, floor CRUD UI, zone edit/delete, slot create/edit | Parking create/edit missing in service/docs | CRUD not complete | PHASE_1_CRUD_BASIC |
| Slot import | Bulk import slot | PARTIAL | `/manager/slots`, `importSlotsApi` | Template/help/validation display | Import error detail | Import can fail opaquely | PHASE_1_CRUD_BASIC |
| Floor plan upload | Upload floor plan | MISSING | MISSING | Upload component, preview | Upload endpoint | Visual planning blocked | PHASE_LATER |
| Visual slot mapping | Map/visual editor | MISSING | MISSING | Canvas/map/grid editor | Coordinate DTOs | High complexity; should not block CRUD | PHASE_LATER |
| Staff management | Staff list/create/toggle active | MISSING | MISSING | Staff route/components | Staff CRUD API | Cannot onboard operators | PHASE_1_CRUD_BASIC |
| Staff red flag permissions | Emergency open/edit/cancel/money flags | MISSING | MISSING | Permission toggles | Staff permission DTO | Unsafe operations uncontrolled in UI | PHASE_1_CRUD_BASIC |
| Kiosk/device binding | Kiosk list, bound devices, allowed staff, revoke | MISSING | MISSING | Kiosk/device pages | Kiosk/device APIs | Device security incomplete | PHASE_1_CRUD_BASIC |
| Emergency approvals | Pending device, approve 8h/reject | MISSING | MISSING | Approval queue | Device request APIs | Staff device onboarding blocked | PHASE_1_CRUD_BASIC |
| Pricing rules | Grace/day/night/block rules | MISSING | MISSING | Pricing editor | Pricing APIs | Billing cannot be configured | PHASE_3_BILLING |
| Pricing matrix | By vehicle type | MISSING | MISSING | Matrix UI | Pricing matrix API | Billing mismatch | PHASE_3_BILLING |
| Subscription | List/create/renew/cancel/expired | MISSING | MISSING | Subscription screens | Subscription APIs | Monthly pass unavailable | PHASE_3_BILLING |
| Incident log | Lost/overtime/wrong plate/force/cancel | MISSING | MISSING | Incident table/forms | Incident APIs | Operations audit gap | PHASE_2_OPERATION |
| Zone violation | Wrong zone, penalty, update actual slot | MISSING | MISSING | Violation UI | Violation APIs | Enforcement gap | PHASE_2_OPERATION |
| Debt notification | Unpaid subscription/reminder | MISSING | MISSING | Debt UI | Debt/reminder APIs | AR workflow missing | PHASE_3_BILLING |
| Analytics revenue | Cash/cashless filters | MISSING | MISSING | Revenue dashboard | Revenue API | Manager cannot reconcile revenue | PHASE_3_BILLING |
| Analytics occupancy | Donut, heatmap, vehicle type filter | MISSING | MISSING | Occupancy dashboard | Occupancy API | Capacity insights missing | PHASE_2_OPERATION |
| Staff entry | Plate input, camera/upload, vehicle type, assignment, open gate | MISSING | `/staff` placeholder | Entry screen/forms | Entry session API, assignment API, image upload | Core operation absent | PHASE_2_OPERATION |
| Staff exit | Plate search, split images, bill, QR/cash, complete | MISSING | `/staff` placeholder | Exit/cashier screen | Exit quote/payment/session APIs | Core cashier absent | PHASE_2_OPERATION |
| Staff live monitor | Slot map color, read-only, drag/drop optional | MISSING | `/staff` placeholder | Monitor map/table | Live slot API | Staff lacks situational view | PHASE_2_OPERATION |
| Staff exceptions | Fuzzy plate, force open, lost ticket, edit reason/image | MISSING | MISSING | Exception forms | Exception APIs | Red actions unaudited | PHASE_2_OPERATION |
| Staff shift handover | End shift, hide system total, cash counted, logout | MISSING | MISSING | Shift form | Shift APIs | Cash control missing | PHASE_2_OPERATION |
| PWA active session | Plate, time, fee, map pin, guide, checkout | MISSING | `/driver` placeholder | Mobile PWA views | Session lookup API | Customer UX absent | PHASE_4_PWA |
| PWA checkout | Bill, VietQR mock, exit pass 15m | MISSING | `/driver` placeholder | Checkout/pass UI | Payment status/pass API | Cannot self-pay | PHASE_4_PWA |
| PWA subscription/invoice | Pass, renew, vehicle registration, PDF | MISSING | `/driver` placeholder | Account/subscription views | PWA subscription APIs | Customer subscriptions absent | PHASE_4_PWA |
| Lazy auth | Phone+plate OTP, QR card/session link | MISSING | MISSING | Lazy auth routes | OTP/session-token APIs | Visitors forced into wrong login model | PHASE_4_PWA |
| Card QR flow | CARD-001, assign card, QR to session | MISSING | MISSING | Card assignment UI | Card/session APIs | Hybrid physical/PWA flow absent | PHASE_2_OPERATION |
