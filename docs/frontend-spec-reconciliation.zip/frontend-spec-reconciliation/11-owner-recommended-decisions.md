# 11 - Owner Recommended Decisions

| Decision | Recommended Choice | Reason | Trade-off | Affected Modules |
|---|---|---|---|---|
| app router/pages router strategy | Keep App Router only | Current repo is `src/app` and Next 16. | Requires App Router discipline for client/server components. | All routes |
| API client strategy | Keep centralized Axios `apiClient` + service layer | Existing admin/manager/auth code follows this. | Need to clean docs/type mismatch. | `src/lib/api`, `src/service/**` |
| auth token storage | Access token memory Zustand, refresh token HttpOnly cookie | Current code and docs align; safer than localStorage refresh token. | Needs bootstrap on reload. | Auth, API client |
| role guard strategy | Central protected layout guard plus route-role map | Current protected group is right place. | Client guard is UX; backend remains security boundary. | `(protected)` routes |
| role layout strategy | Shared Admin/Manager shell; separate Staff kiosk and PWA mobile shell | Staff/PWA workflows differ strongly from admin dashboards. | More layouts to maintain. | Layout/navigation |
| tenant handling strategy | Do not send tenantId for manager/staff/user APIs | Manager API spec requires JWT `tenant_id` backend context. | Backend must be consistent. | API services |
| route naming convention | Keep `/admin`, `/manager`, `/staff`; decide `/driver` vs `/pwa` | Existing role redirects use `/driver` for PARKING_USER. | Renaming later is costly. | Routes/nav/auth redirect |
| UI library convention | Continue shadcn/ui + Tailwind + lucide | Existing components and package setup use it. | Custom component quality must be maintained. | All UI |
| form validation convention | React Hook Form + Zod | Existing forms use it. | Some schema duplication unless organized. | CRUD forms |
| table pattern | Use shadcn table primitives now; extract data table later | Current duplication is manageable. | Later refactor if sorting/column config grows. | Admin/Manager CRUD |
| modal/drawer pattern | Dialog for small CRUD; drawer later for dense edit forms | Existing code uses Dialog. | Drawers may be better on large manager forms later. | CRUD forms |
| staff kiosk UX | Desktop-first, task-focused, no admin sidebar by default | Bốt gác needs fast operations, not SaaS admin navigation. | Separate shell work. | Staff |
| PWA in same repo vs separate app | Same repo initially under separate mobile route group if owner agrees | Reuses auth/API/types while product is young. | Bundle/navigation separation must be managed. | PWA |
| mock API layer strategy | Only typed, clearly marked MOCK_ONLY modules when backend absent | Prevents fake UI from being mistaken as integrated. | Slight setup overhead. | Future modules |
| chart library strategy | Keep Recharts | Already installed and used for admin traffic chart. | Advanced heatmaps may need custom/extra library later. | Analytics |
| camera upload/mock strategy | Phase 2 starts with upload/image mock; real camera later | Reduces browser permission/device risk. | Staff UX not fully realistic initially. | Staff entry/exit |
| QR/payment mock strategy | Mock VietQR/QR in Phase 3/4 until payment contract is signed | Avoids premature gateway coupling. | No real payment until later. | Billing/PWA |
