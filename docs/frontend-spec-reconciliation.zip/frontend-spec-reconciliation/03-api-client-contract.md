# 03 - API Client Contract

## API Client Findings

- API base URL: `NEXT_PUBLIC_API_URL` with fallback `http://localhost:8080` in `src/lib/api/api-url.ts`.
- Fetcher: Axios instance `apiClient` in `src/lib/api/axios-config.ts`.
- Interceptors: request interceptor injects `Authorization: Bearer <jwtToken>`; response interceptor unwraps logical errors, handles 401 refresh retry, maps 403 to `ApiError`.
- Token injection: memory token from `useAuthStore.getState().jwtToken`.
- 401 handling: refresh via raw `axios.post(`${apiUrl}/auth/refresh`)`, queue pending requests, retry original request.
- 403 handling: generic `ApiError`; no route/device-specific UI.
- Error convention: `ApiResponse<T>` with `code`, `message`, optional `result`, `errors`, `timestamp`, `path`; success expected `code === 1000`.
- Loading/error states: most API pages use React Query loading skeletons and Sonner toasts.
- Tenant handling: frontend does not send `tenantId` manually in services. This matches `docs/manager-facility-api-spec.md`, which says manager endpoints must use JWT `tenant_id` and frontend must not send tenant id.

## API Calls

| API Call Purpose | Frontend File | Method | URL/Path | Request Shape | Response Expected | Auth Header? | Env Used | Backend Match Status | Notes |
|---|---|---|---|---|---|---|---|---|---|
| Login | `src/service/user/api.ts` | POST | `/auth/login` | `LoginRequest { username, password, deviceFingerprint, deviceLabel? }` | `AuthenticationResponse` | Optional/no before login | `NEXT_PUBLIC_API_URL` | CONTRACT_UNCLEAR | Code exists; docs describe flow, but backend auth spec not in current docs beyond frontend docs. |
| Refresh | `src/service/user/api.ts`, `src/lib/api/axios-config.ts` | POST | `/auth/refresh` | Empty body, credentials cookie | `AuthenticationResponse` | No Bearer, cookie credentials | `NEXT_PUBLIC_API_URL` | CONTRACT_UNCLEAR | Refresh cookie contract assumed. |
| Current profile | `src/service/user/api.ts` | GET | `/auth/me` | None | `UserProfile` | Yes | `NEXT_PUBLIC_API_URL` | CONTRACT_UNCLEAR | Profile fields in code; backend contract not separately present. |
| Logout | `src/service/user/api.ts` | POST | `/auth/logout` | None | `void` envelope | Yes | `NEXT_PUBLIC_API_URL` | CONTRACT_UNCLEAR | API function unused by UI. |
| Logout all | `src/service/user/api.ts` | POST | `/auth/logout-all` | None | `void` envelope | Yes | `NEXT_PUBLIC_API_URL` | CONTRACT_UNCLEAR | API function unused by UI. |
| Admin dashboard stats | `src/service/admin/api.ts` | GET | `/admin/dashboard/stats` | None | `AdminDashboardStatsResponse` | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | Matched `docs/frontend-types-contract.md`. |
| List tenants | `src/service/admin/api.ts` | GET | `/admin/tenants?page&size` | query `page`, `size` | `ApiPageResponse<TenantItem>` | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | Matched `docs/frontend-types-contract.md`. |
| Provision tenant | `src/service/admin/api.ts` | POST | `/admin/tenants` | `{ companyName, managerEmail, initialPassword }` | `TenantItem` | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | Spec asks manager email/username; current contract only `managerEmail`. |
| Toggle tenant status | `src/service/admin/api.ts` | PATCH | `/admin/tenants/{id}/status` | None | `TenantItem` | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | No target status body; backend toggles. |
| List vehicle types | `src/service/admin/api.ts` | GET | `/admin/master-data/vehicle-types` | None | `VehicleTypeItem[]` | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | Global admin master data. |
| Create vehicle type | `src/service/admin/api.ts` | POST | `/admin/master-data/vehicle-types` | `{ name, code, active }` | `VehicleTypeItem` | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | UI wired. |
| Update vehicle type | `src/service/admin/api.ts` | PUT | `/admin/master-data/vehicle-types/{id}` | `{ name, code, active }` | `VehicleTypeItem` | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | UI wired. |
| Delete vehicle type | `src/service/admin/api.ts` | DELETE | `/admin/master-data/vehicle-types/{id}` | None | `null` result | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | UI wired; no confirm dialog. |
| List roles | `src/service/admin/api.ts` | GET | `/admin/master-data/roles` | None | `RoleItem[]` | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | List only. |
| List manager parkings | `src/service/manager/facility-api.ts` | GET | `/manager/parkings` | None | `ParkingResponse[]` | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | Matched `docs/manager-facility-api-spec.md`; no tenantId sent. |
| Toggle parking status | `src/service/manager/facility-api.ts` | PATCH | `/manager/parkings/{id}/status` | None | `ParkingStatusResponse` | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | Backend toggles active/maintenance. |
| Get parking topology | `src/service/manager/facility-api.ts` | GET | `/manager/parkings/{id}/topology` | None | `ParkingTopologyResponse` | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | UI view only plus zone create. |
| List floors | `src/service/manager/facility-api.ts` | GET | `/manager/parkings/{parkingId}/floors` | None | `FloorResponse[]` | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | API exists, no UI uses it directly. |
| Create floor | `src/service/manager/facility-api.ts` | POST | `/manager/parkings/{parkingId}/floors` | `FloorRequest` | `FloorResponse` | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | API exists, no UI. |
| Get/update/delete floor | `src/service/manager/facility-api.ts` | GET/PUT/DELETE | `/manager/floors/{id}` | `FloorRequest` for PUT | `FloorResponse` or null | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | API exists, no UI. |
| List/create/get/update/delete zones | `src/service/manager/facility-api.ts` | GET/POST/GET/PUT/DELETE | `/manager/floors/{floorId}/zones`, `/manager/zones/{id}` | `ZoneRequest` | `ZoneResponse` | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | Create zone UI exists; edit/delete UI missing. |
| List slots | `src/service/manager/facility-api.ts` | GET | `/manager/slots` | query `zoneId,status,slotCode,exact,page,size` | `SlotPageResponse` | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | UI sends zone ID manually as filter, not tenantId. |
| Bulk update slot status | `src/service/manager/facility-api.ts` | PATCH | `/manager/slots/bulk-status` | `{ slotIds, newStatus }` | `SlotBulkStatusResponse` | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | UI exposes AVAILABLE and MAINTENANCE only, despite type also allowing LOCKED. |
| Import slots | `src/service/manager/facility-api.ts` | POST | `/manager/slots/import` | multipart `file` | `SlotImportResponse` | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | Excel import wired. |
| Export slots | `src/service/manager/facility-api.ts` | GET | `/manager/slots/export` | None | Blob file | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | Binary exception documented. |
| Manager vehicle types | `src/service/manager/facility-api.ts` | GET | `/manager/master-data/vehicle-types` | None | `GlobalVehicleTypeResponse[]` | Yes | `NEXT_PUBLIC_API_URL` | MATCHED_DOC | Used by create zone select. |

## Contract Risks

| Concern | Status | Evidence | Notes |
|---|---|---|---|
| Central API client | DONE | `src/lib/api/axios-config.ts` | All app services use it except raw refresh by design. |
| Interceptor return type | UNCLEAR | `src/lib/api/axios-config.ts`, `docs/04-api-and-react-query.md` | Docs mention interceptor returning `response.data`, but current code returns Axios response in success branch. Service code currently expects AxiosResponse. |
| Auth bootstrap | MISSING | `src/app/providers.tsx` | No initial `/auth/refresh` + `/auth/me`. |
| Device trust code | CONTRACT_UNCLEAR | `src/lib/api/axios-config.ts` | 403 generic; no code enum for unknown device. |
| Tenant context | DONE | `src/service/manager/facility-api.ts`, `docs/manager-facility-api-spec.md` | Frontend does not send tenantId manually; keep this. |
